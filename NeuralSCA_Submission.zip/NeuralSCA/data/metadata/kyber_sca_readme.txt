This project contains the implementation of Kyber512 with Chosen Ciphertext (CCA-Kyber512) based on pqm4 library, Matlab codes about secret-key recovery and success rate (Matlab codes), and test data set (real secret key and trace data).

'CCA-Kyber512' folder (zipped):
-C_fqmul:  C-reference implementation with chosen cipertexts. Please refer to 'ReadMe-zx' for more information.
-m4_poly_from_msg: m4 implementation with chosen cipertexts. Please refer to 'ReadMe-zx' for more information.

'Matlab' folder:
-functions: Several functions that need to be called
-3 Matlab codes for analysis on C implementation, M4 implementation(-O0) and M4 implementation(-O3) respectively.

'Test Data Set' folder (zipped):
-Real_sk:  random generated secret keys data sets
-Trace_data: traces generated from chosen ciphertexts

