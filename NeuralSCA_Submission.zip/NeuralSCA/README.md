# NeuralSCA: Accelerated Neural Side-Channel Analysis of Masked ML-KEM

[![Python 3.12+](https://img.shields.io/badge/python-3.12+-blue.svg)](https://www.python.org/downloads/)
[![PyTorch 2.6+](https://img.shields.io/badge/PyTorch-2.6+-ee4c2c.svg)](https://pytorch.org/)
[![ONNX Runtime](https://img.shields.io/badge/ONNX_Runtime-1.19+-005CED.svg)](https://onnxruntime.ai/)
[![NIST Standard](https://img.shields.io/badge/NIST_PQC-FIPS_203_(ML--KEM)-darkgreen.svg)](https://csrc.nist.gov/pubs/fips/203/final)
[![License: GPL v3](https://img.shields.io/badge/License-GPLv3-blue.svg)](LICENSE)
[![Research Paper PDF](https://img.shields.io/badge/Paper-24BCE7727__neuralSCA.pdf-red.svg)](24BCE7727_neuralSCA.pdf)
[![Tests Passing](https://img.shields.io/badge/Unit_Tests-16%2F16_Passed-brightgreen.svg)](#examiner--reviewer-quick-start-60-second-reproducibility)
[![Open In Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/hardikxk/pqc-sca/blob/main/notebooks/colab_train.ipynb)

> **Academic Project Submission**  
> **Candidate:** Hardik Kumar &nbsp;|&nbsp; **Registration No:** `24BCE7727`  
> **Institution:** School of Computer Science and Engineering (SCOPE), Vellore Institute of Technology, Andhra Pradesh (VIT-AP)  
> **Research Title:** *Accelerated Neural Side-Channel Analysis of Masked ML-KEM Using Quantum-Inspired Architectures*  
> **Target Standard:** NIST FIPS 203 (ML-KEM / CRYSTALS-Kyber) on 32-bit ARM Cortex-M4  
> **Compiled Manuscript:** [`24BCE7727_neuralSCA.pdf`](24BCE7727_neuralSCA.pdf) &nbsp;|&nbsp; **LaTeX Sources:** [`paper/main.tex`](paper/main.tex)

> **NeuralSCA** is a lightweight, end-to-end deep learning side-channel analysis (DL-SCA) profiling pipeline engineered to evaluate the physical hardware security of **NIST FIPS 203 (ML-KEM / CRYSTALS-Kyber)** on embedded microcontrollers.
> 
> It eliminates the severe memory and parameter bottlenecks of post-quantum side-channel profiling by combining **bounded-memory streaming HDF5 ingestion** ($<112\text{ MB}$ peak RAM) with a **quantum-inspired Matrix Product State (MPS) tensor network** ($9,226$ parameters, $35.9\%$ smaller than baseline CNNs) and **dynamic symmetric Int8 ONNX deployment** ($0.14\text{ ms per trace}$ on a standard CPU).

---

## Table of Contents
- [Examiner & Reviewer Quick-Start (60-Second Reproducibility)](#examiner--reviewer-quick-start-60-second-reproducibility)
- [Executive Summary](#executive-summary)
- [System Architecture](#system-architecture)
- [Empirical Results & Benchmark Highlights](#empirical-results--benchmark-highlights)
- [Comparison with Existing Alternatives](#comparison-with-existing-alternatives)
- [Interactive Google Colab & Jupyter Notebooks](#interactive-google-colab--jupyter-notebooks)
- [Interactive Developer Console & Web Testbed](#interactive-developer-console--web-testbed)
- [Quick Start (One-Click Demo)](#quick-start-one-click-demo)
- [Step-by-Step Modular Pipeline](#step-by-step-modular-pipeline)
- [Available Datasets (Real & Synthetic)](#available-datasets-real--synthetic)
- [Hardware Cryptographic Audit & Reproducibility](#hardware-cryptographic-audit--reproducibility)
- [Research Paper & Explanation Guides](#research-paper--explanation-guides)
- [Repository Structure](#repository-structure)
- [Responsible Disclosure & Ethical Statement](#responsible-disclosure--ethical-statement)
- [Citation](#citation)
- [License](#license)

---

## Examiner & Reviewer Quick-Start (60-Second Reproducibility)

This repository is structured for **100% turnkey academic and peer-review reproducibility**. Reviewers and examiners can verify all claims in four simple commands:

```bash
# 1. Clone repository & check environment
git clone https://github.com/hardikxk/pqc-sca.git && cd pqc-sca
python scripts/00_check_environment.py

# 2. Run automated test suite (16 tests covering streaming, MPS math, ONNX, and reproducibility)
python -m unittest discover -s tests -v

# 3. Verify research paper citation integrity & LaTeX mathematical rigor
python scripts/verify_paper.py

# 4. Launch unified pipeline demo & interactive dark-mode developer console
python demo.py
```

> **Prefer Cloud Execution?**  
> Click the [![Open In Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/hardikxk/pqc-sca/blob/main/notebooks/colab_train.ipynb) badge to run the full training pipeline on a free **NVIDIA Tesla T4 GPU** in Google Colab with zero local installation.

---

## Executive Summary

When post-quantum lattice cryptography primitives such as **ML-KEM-512** are executed on physical silicon (such as 32-bit ARM Cortex-M4 microcontrollers), the internal arithmetic loops of the **Number Theoretic Transform (NTT)** unintentionally leak sensitive information through instantaneous power consumption and electromagnetic (EM) emissions. 

While algorithmic **Boolean masking** ($x = x_1 \oplus x_2$) splits secrets into randomized shares to prevent first-order leakage, non-linear arithmetic conversions (A2B/B2A) introduce higher-order vulnerabilities that deep learning models can exploit. However, existing DL-SCA tools fail when applied to PQC targets:
1. **The Ingestion Wall:** A $100,000$-trace dataset of length $L = 41,800$ samples requires over **$16.7\text{ GB}$ of RAM** in standard NumPy/PyTorch arrays, immediately causing Out-Of-Memory (OOM) crashes on standard developer machines.
2. **The Parameter Explosion:** Mapping long PQC traces into standard dense classification heads creates over $400,000$ trainable parameters, causing severe overfitting on low-SNR physical noise.

**NeuralSCA resolves both challenges:**
- **Streaming Pipeline:** Processes traces in contiguous chunks ($B=256$) with zero-phase digital FIR filtering, template cross-correlation alignment, and POI decimation to $5,000$ points, capping peak RAM at **$\le 111.8\text{ MB}$** ($>99.3\%$ memory reduction) with a sustained throughput of **$761.2\text{ traces/s}$**.
- **Quantum-Inspired MPS Head:** Replaces the dense classifier with a low-rank Matrix Product State tensor network ($\chi = 8$). It shrinks trainable parameters to **$9,226$** ($35.93\%$ smaller than the 1D-CNN baseline and utilizing only $4.6\%$ of the $200\text{k}$ budget ceiling), speeds up training by **$1.69\times$**, and drives **Guessing Entropy to Rank 1.0** on masked ML-KEM-512.
- **Quantized Edge Deployment:** Dynamically quantized to **Int8 ONNX** ($18.6\text{ KB}$ binary), executing single-threaded CPU inference in **$0.14\text{ ms per trace}$** ($7,142\text{ traces/second}$).

---

## System Architecture

![NeuralSCA Architecture & Component Animation](results/figures/architecture_pipeline_animated.gif)
*Figure: End-to-end animated dataflow showing bounded-memory streaming ingestion ($<112\text{ MB}$), zero-phase FIR filtering, quantum-inspired MPS tensor contraction ($\chi=8, 9,226\text{ params}$), and Guessing Entropy convergence to Rank 1.0. High-res video: [`architecture_pipeline_animated.mp4`](results/figures/architecture_pipeline_animated.mp4).*

```text
+-----------------------------------------------------------------------------------------+
|                                NeuralSCA Core Dataflow                                  |
+-----------------------------------------------------------------------------------------+
|                                                                                         |
|  [Raw HDF5 Container] (100k traces, L=41,800 samples)                                   |
|            |                                                                            |
|            v                                                                            |
|  [Stage 1: Streaming Ingestion]  --> Lazy generator chunk iterator (B=256, Peak <112 MB) |
|            |                                                                            |
|            v                                                                            |
|  [Stage 2: Digital Filtering]    --> Zero-phase FIR low-pass filter (N=31, fc=0.25)     |
|            |                                                                            |
|            v                                                                            |
|  [Stage 3: Phase Alignment]      --> Template cross-correlation alignment (Δτ = ±100)   |
|            |                                                                            |
|            v                                                                            |
|  [Stage 4: POI Decimation]       --> Downsample to D=5,000 salient NTT butterfly features|
|            |                                                                            |
|            v                                                                            |
|  [Stage 5: Z-Score Scaling]      --> Zero-mean, unit-variance per-trace normalization   |
|            |                                                                            |
|            v                                                                            |
|  [Stage 6: Hybrid Profiler]      --> 1D-CNN Backbone + Quantum-Inspired MPS Head (χ=8)   |
|                                      Total Parameters: 9,226 (<5% of 200k ceiling)      |
|            |                                                                            |
|            v                                                                            |
|  [Stage 7: Edge Runtime & Audit] --> Dynamic Int8 ONNX Runtime (0.14 ms/tr on CPU)       |
|                                  --> Cryptographic SHA-256 Provenance Manifest          |
|                                                                                         |
+-----------------------------------------------------------------------------------------+
```

---

## Empirical Results & Benchmark Highlights

All benchmarks were recorded on standard consumer commodity hardware (x86_64 CPU, 16 GB RAM, zero dedicated GPU requirement):

### 1. Ingestion & Preprocessing Throughput
| Pipeline Implementation | Dataset Size | Raw Length | Peak Memory (RSS) | Throughput | Acceleration |
|---|---|---|---|---|---|
| **Monolithic Python/NumPy** | $100,000$ | $41,800$ | $>16.5\text{ GB}$ (OOM) | Failed (Crashed) | — |
| **Standard Chunked SciPy** | $100,000$ | $41,800$ | $251.5\text{ MB}$ | $85.4\text{ traces/s}$ | $1.00\times$ (Baseline) |
| **NumPy Optimized Chunked** | $100,000$ | $41,800$ | $100.9\text{ MB}$ | $557.7\text{ traces/s}$ | $6.53\times$ |
| **NeuralSCA Streaming Engine** | $\mathbf{100,000}$ | $\mathbf{41,800}$ | $\mathbf{111.8\text{ MB}}$ ($>99.3\%$ drop) | $\mathbf{761.2\text{ traces/s}}$ | $\mathbf{8.91\times}$ |

![Preprocessing Speedup](results/figures/preprocessing_speedup.png)
*Figure 1: Peak memory footprint ($<112\text{ MB}$ vs. $>16.5\text{ GB}$) and sustained preprocessing throughput ($761.2\text{ traces/s}$, $8.91\times$ acceleration over SciPy baseline).*

### 2. Model Complexity & Parameter Footprint
| Model Architecture | Conv Feature Params | Head Classifier Params | Total Trainable Params | Epoch Time | Budget (<200k) |
|---|---|---|---|---|---|
| **1D-CNN Baseline (Dense Head)** | $5,984$ | $8,416$ | $14,400$ | $0.1065\text{ s}$ | PASSED (7.2%) |
| **CNN + MPS (Tensor Network, Ours)** | $\mathbf{5,984}$ | $\mathbf{3,242}$ | $\mathbf{9,226}$ ($\mathbf{35.93\%}$ compression) | $\mathbf{0.0630\text{ s}}$ ($\mathbf{1.69\times}$ faster) | **PASSED (4.61%)** |

![Model Comparison](results/figures/model_comparison.png)
*Figure 2: Architecture comparison between the standard 1D-CNN baseline and our quantum-inspired CNN+MPS model, demonstrating a $35.9\%$ parameter reduction and $1.69\times$ training speedup.*

### 3. Key Recovery via Guessing Entropy ($GE$)
| Target Implementation | Initial Rank ($m=1$) | GE @ $m=20$ | GE @ $m=50$ | GE @ $m=100$ | Final Key Rank |
|---|---|---|---|---|---|
| **Unprotected ML-KEM-512** | $128.0$ (Random) | $5.0$ | $2.1$ | $1.0$ | **1.0 (Unique Recovery)** |
| **Masked ML-KEM-512 (ARM Cortex-M4)** | $128.0$ (Random) | $38.2$ | $18.4$ | $4.2$ | **1.0 (Bypassed Masking)** |

![Guessing Entropy Curve](results/figures/ge_curve.png)
*Figure 3: Empirical Guessing Entropy ($GE$) curve on masked ML-KEM-512 power traces, converging exponentially to Rank 1.0 (full secret key recovery).*

### 4. Edge Quantization & Local CPU Inference Latency
| Deployment Format | Precision | Serialized Size | CPU Latency / Trace | Sustained Throughput |
|---|---|---|---|---|
| **PyTorch Checkpoint** | FP32 | $58.4\text{ KB}$ | $0.92\text{ ms}$ | $1,086\text{ traces/s}$ |
| **ONNX Runtime (Unquantized)** | FP32 | $42.1\text{ KB}$ | $0.38\text{ ms}$ | $2,631\text{ traces/s}$ |
| **ONNX Runtime (Dynamic Int8, Ours)** | **Int8** | $\mathbf{18.6\text{ KB}}$ ($68.2\%$ reduction) | $\mathbf{0.14\text{ ms}}$ | $\mathbf{7,142\text{ traces/s}}$ |

---

## Comparison with Existing Alternatives

The table below summarizes how **NeuralSCA** compares against the prevailing side-channel profiling paradigms:

| Profiling Paradigm / Framework | Ingestion RAM ($100\text{k}$) | Trainable Parameters | Hardware Dependency | Masking Bypass ($d=2$) | CPU Latency / Trace | Audit Trail |
|---|---|---|---|---|---|---|
| **Classical 2nd-Order CPA (SCALib / Lascar)** | $>4.2\text{ GB}$ | N/A (Statistical) | CPU Only | Weak (Combinatorial failure under jitter) | $>12.40\text{ ms}$ (Pairwise) | Manual scripts |
| **ASCAD Baseline CNN (Dense Head)** | $>16.5\text{ GB}$ (OOM) | $420,000+$ (Head explosion) | High-VRAM GPU | Moderate (Prone to noise overfitting) | $1.25\text{ ms}$ (FP32) | Static scripts |
| **Heavyweight Deep ResNet-18 Profiler** | $>16.5\text{ GB}$ (OOM) | $>1,200,000$ | Dedicated GPU (CUDA) | High (Slow convergence) | $4.80\text{ ms}$ (FP32) | None |
| **Standard 1D-CNN Baseline (Dense Head)** | $100.9\text{ MB}$ | $14,400$ | Commodity CPU / GPU | Moderate ($GE \to 1.0$) | $0.38\text{ ms}$ (ONNX FP32) | SHA-256 Manifest |
| **NeuralSCA (Ours: 1D-CNN + MPS)** | $\mathbf{111.8\text{ MB}}$ | $\mathbf{9,226}$ | **Commodity CPU Only** | **High ($GE \to 1.0$ in $\le 150$ traces)** | $\mathbf{0.14\text{ ms}}$ (Int8 ONNX) | **Automated SHA-256** |

### Why NeuralSCA is Superior:
1. **No Out-of-Memory Failures:** Bounded streaming chunking ($B=256$) eliminates the $16.7\text{ GB}$ memory wall, running large datasets within $\le 111.8\text{ MB}$ of RAM.
2. **Anti-Overfitting Low-Rank Regularization:** Unlike massive ResNet/VGG models ($>1.2\text{M}$ params) or dense heads ($>420\text{k}$ params) that memorize oscilloscope noise, the MPS tensor network ($\chi = 8$) strictly bounds virtual entanglement entropy, filtering uncorrelated noise while extracting multi-share leakage.
3. **Automated Feature Extraction:** Overcomes the $\mathcal{O}(L^2)$ combinatorial bottleneck of 2nd-order CPA by extracting shift-invariant features via 1D-CNN convolutions.
4. **Edge Deployment Without GPUs:** Dynamic Int8 ONNX quantization runs at $0.14\text{ ms per trace}$ ($>7,100\text{ traces/s}$) on standard consumer laptop CPUs.

---

## Interactive Google Colab & Jupyter Notebooks

For users who prefer cloud GPU execution or wish to experiment without a local environment, three fully self-contained Jupyter notebooks are provided in [`notebooks/`](notebooks/):

| Notebook | Open in Colab | Target Hardware | Estimated Runtime | Primary Workflow |
|---|:---:|:---:|:---:|---|
| **End-to-End Colab Training**<br>[`colab_train.ipynb`](notebooks/colab_train.ipynb) | [![Open In Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/hardikxk/pqc-sca/blob/main/notebooks/colab_train.ipynb) | **T4 GPU** / CPU | ~10–15 min | Full pipeline: synthetic trace generation, bounded streaming preprocessing, baseline 1D-CNN vs. CNN+MPS tensor network training, Guessing Entropy convergence, and Int8 ONNX export. |
| **Quick 5-Minute Demo**<br>[`quick_demo.ipynb`](notebooks/quick_demo.ipynb) | [![Open In Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/hardikxk/pqc-sca/blob/main/notebooks/quick_demo.ipynb) | Free CPU / GPU | ~5 min | Fast, compact iteration over 2,000 traces. Verifies streaming dataflow, model architectures, and parameter budget compliance ($<200\text{k}$). |
| **Results Visualization & Analysis**<br>[`results_visualization.ipynb`](notebooks/results_visualization.ipynb) | [![Open In Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/hardikxk/pqc-sca/blob/main/notebooks/results_visualization.ipynb) | Free CPU | <2 min | Publication-ready visual analytics: multi-stage oscilloscope waveforms, digital filtering comparisons, Guessing Entropy curves, and parameter footprint radar charts. |

### Running on Google Colab:
1. Click the **Open In Colab** badge for any of the notebooks above.
2. In Google Colab, select **Runtime → Change runtime type → T4 GPU** (or keep the default CPU runtime for `quick_demo.ipynb` / `results_visualization.ipynb`).
3. Run **Runtime → Run all** (or step through cell-by-cell). The notebooks clone the repository, install dependencies, and run seamlessly without requiring manual configuration.

---

## Interactive Developer Console & Web Testbed

NeuralSCA includes a browser-based, dark-mode developer console and live oscilloscope testbed built with a terminal aesthetic (`#000000` canvas, zinc typography, monochrome charts, zero layout jumping).

The console includes 6 functional tabs:
1. **Overview & Execution Summary:** Real-time pipeline status, phase completion indicators, and parameter budget compliance ($9,226 / 200,000$).
2. **Oscilloscope Waveforms:** Multi-trace interactive waveform visualizer showing raw traces, zero-phase FIR filtered waveforms, phase alignment translations, and decimated $5,000$-sample POI regions.
3. **Model Architecture:** Visual tensor dimension comparison between the 1D-CNN baseline ($14,400$ params) and the CNN+MPS tensor network ($9,226$ params).
4. **Attack Testbed & Key Recovery:** Real-time Guessing Entropy ($GE$) curve tracking convergence towards Rank $1.0$ across attack trace prefixes.
5. **Inference Testbed:** Live edge inference simulator executing the dynamic Int8 ONNX model with latency distribution and candidate byte posterior probabilities.
6. **Audit & Manifest:** Cryptographic SHA-256 fingerprint verification table auditing all datasets, models, and configuration files.

---

## Quick Start (One-Click Demo)

With the [`uv`](https://docs.astral.sh/uv/) runtime installed, launch the entire pipeline and developer testbed with a single command:

```powershell
# Run smoke demo, execute pipeline, and open the web dashboard at http://127.0.0.1:8000
uv run demo.py
```

### Command Options:
```powershell
# Run full-size training and benchmarking:
uv run demo.py --full

# Train on physical masked ML-KEM-512 power traces:
uv run demo.py --dataset masked

# Train on unprotected ML-KEM-512 traces:
uv run demo.py --dataset unprotected

# Terminal-only execution (runs full pipeline without starting web server):
uv run demo.py --cli-only

# Start dashboard immediately from existing artifacts without retraining:
uv run demo.py --skip-pipeline

# Run on a custom port without auto-launching browser:
uv run demo.py --port 8080 --no-browser
```

---

## Step-by-Step Modular Pipeline

You can also run every pipeline stage individually using the standalone scripts in `scripts/`:

```powershell
# 0. Check Environment & Tooling
python scripts/00_check_environment.py

# 1. Generate Deterministic Synthetic NTT Traces (or convert real data)
python scripts/01_generate_synthetic_dataset.py --profiling 32 --attack 8 --trace-length 20000

# 2. Run Streaming Preprocessing Baseline (FIR, Alignment, POI decimation)
python scripts/02_python_preprocess_baseline.py

# 3. Validate Dataset Contract (Non-finite checks, label ranges)
python scripts/12_validate_dataset.py --input data/processed/python_processed.h5 --strict

# 4. Train 1D-CNN Baseline
python scripts/04_train_cnn.py --epochs 10 --batch-size 16 --device auto

# 5. Train Quantum-Inspired CNN + MPS Model
python scripts/05_train_cnn_mps.py --epochs 10 --batch-size 16 --bond-dim 8 --device auto

# 6. Evaluate Guessing Entropy (Key Rank Convergence)
python scripts/06_evaluate_ge.py --input data/processed/python_processed.h5

# 7. Benchmark Model & Preprocessing Footprints
python scripts/07_benchmark_models.py
python scripts/08_benchmark_preprocessing.py

# 8. Export to Dynamic Int8 ONNX & Benchmark CPU Inference Latency
python scripts/09_export_onnx.py
python scripts/10_local_inference.py

# 9. Generate Cryptographic Provenance Manifest
python scripts/13_create_run_manifest.py --dataset data/processed/python_processed.h5
```

---

## Available Datasets (Real & Synthetic)

The repository provides both reproducible synthetic benchmarks and physical acquisition campaigns:

| Dataset Identifier | Location | Traces & Samples | Description |
|---|---|---|---|
| **Synthetic PQC Baseline** | `data/raw/synthetic_pqc.h5` | 32/8 up to 10k/2k, $L=5,000$ | Deterministic NTT leakage generator for rapid testing, CI, and smoke verification. |
| **Real Masked ML-KEM-512** | `data/raw/mlkem_masked_converted.h5` | 100,000 prof / 100,000 atk, $L=41,800$ | Physical power acquisitions from 32-bit ARM Cortex-M4 running 1st-order Boolean masked ML-KEM-512 (Zenodo). |
| **Real Unprotected ML-KEM-512** | `data/raw/mlkem_unprotected_converted.h5` | 10,000 prof / 10,000 atk, $L=28,600$ | Physical power traces from ARM Cortex-M4 without countermeasures for leakage comparison. |
| **Kyber Case-Study Matrices** | `data/metadata/confusion_matrices/` | N/A | KU Leuven reference matrices and belief-propagation artifacts. |

### Ingesting External Zenodo / PQM4 Datasets:
Inspect external HDF5 files without loading trace payloads:
```powershell
python scripts/11_convert_external_hdf5.py --input path/to/external_traces.h5 --inspect
```

Convert external traces into the project streaming contract:
```powershell
python scripts/11_convert_external_hdf5.py `
  --input path/to/external_traces.h5 `
  --output data/raw/mlkem_converted.h5 `
  --label-byte 0 `
  --profiling-limit 10000 `
  --attack-limit 2000
```

---

## Hardware Cryptographic Audit & Reproducibility

Every execution of the pipeline automatically records an immutable, verifiable manifest in `results/benchmarks/run_manifest.json`:
- **Git Commit & Dirty State:** Exact code snapshot.
- **Environment Metadata:** OS, CPU architecture, Python version, library versions.
- **SHA-256 Digests:** Cryptographic fingerprinting for raw HDF5 files, preprocessed containers, model weights (`.pt`), and ONNX runtime graphs (`.onnx`).
- **Dataset Contract Verification:** Enforces shape consistency, absence of `NaN`/`Inf` values, and valid class boundaries $[0, 255]$.

---

## Research Paper & Academic Artifacts

This project includes a complete academic manuscript ready for submission to top-tier security and AI venues (AAAI / CHES / IEEE S&P):

- **Primary Manuscript (PDF):** [`24BCE7727_neuralSCA.pdf`](24BCE7727_neuralSCA.pdf)
  - Full-length academic research manuscript compiled according to AAAI specifications.
- **LaTeX Source Repository:** [`paper/main.tex`](paper/main.tex)
  - Standard AAAI 2-column format with unnumbered subheadings (`secnumdepth = 1`).
  - 58 embedded academic citations with verified DOIs and URLs in [`paper/references.bib`](paper/references.bib) and [`paper/main.bbl`](paper/main.bbl).
  - Formal pseudocode in **Algorithm 1**, complete architectural specs in **Tables 1–5**, and comprehensive comparative benchmarks in **Table 6**.
- **Automated Verification Script:** [`scripts/verify_paper.py`](scripts/verify_paper.py)
  - Verifies that all 58 citations exist in both `.tex` and `.bbl` files and confirms that curly braces and LaTeX math blocks are 100% balanced.

---

## Repository Structure

```text
NeuralSCA/
├── 24BCE7727_neuralSCA.pdf     # Primary compiled academic research paper
├── config/                     # YAML pipeline configurations (default.yaml, colab.yaml)
├── data/
│   ├── raw/                    # Raw & converted HDF5 trace files
│   ├── processed/              # Filtered, aligned, and decimated HDF5 datasets
│   └── metadata/               # Acquisition metadata & confusion matrices
├── mojopqc_sca/
│   ├── datasets/               # Chunked HDF5 loaders, IterableDataset & contract validation
│   ├── models/                 # 1D-CNN baseline, MPS tensor layers, parameter counters
│   ├── preprocessing/          # Zero-phase FIR filtering, template alignment, POI decimation
│   └── evaluation/             # Cumulative log-likelihood, Guessing Entropy & rank metrics
├── scripts/                    # Numbered standalone pipeline execution scripts (00 to 13)
├── notebooks/                  # Interactive Google Colab & Jupyter notebooks
│   ├── colab_train.ipynb       # End-to-end GPU training pipeline on Colab
│   ├── quick_demo.ipynb        # Fast 5-minute CPU/GPU walkthrough
│   └── results_visualization.ipynb # Publication figures & metric plots
├── results/
│   ├── models/                 # Trained checkpoints (.pt) and Int8 ONNX graphs (.onnx)
│   ├── benchmarks/             # Throughput, memory, latency, and run_manifest.json
│   └── figures/                # Waveforms, parameter comparisons, and GE convergence plots
├── paper/                      # AAAI LaTeX research paper, references.bib & main.bbl
├── demo.py                     # Unified runner and interactive developer console web testbed
├── pyproject.toml              # Modern Python packaging configuration
└── requirements.txt            # Declared dependencies
```

---

## Responsible Disclosure & Ethical Statement

This project was developed strictly for academic, educational, and defense-hardening purposes. Side-channel vulnerability profiling is an indispensable methodology for evaluating cryptographic implementations to ensure that post-quantum standards (such as NIST FIPS 203) are physically resilient against real-world side-channel attacks before widespread deployment in critical infrastructure, defense systems, and embedded consumer hardware. All physical acquisitions and experiments were conducted on authorized embedded evaluation targets and open research datasets in accordance with responsible disclosure principles.

---

## Citation

If you use NeuralSCA in your research, please cite our paper:

```bibtex
@article{kumar2026accelerated,
  author    = {Kumar, Hardik},
  title     = {{Accelerated Neural Side-Channel Analysis of Masked ML-KEM Using Quantum-Inspired Architectures}},
  journal   = {School of Computer Science and Engineering, Vellore Institute of Technology, Andhra Pradesh},
  year      = {2026},
  note      = {Artifact repository: \url{https://github.com/hardikxk/pqc-sca}}
}
```

---

## License
This project is licensed under the [GNU General Public License v3.0 (GPL-3.0)](LICENSE).

