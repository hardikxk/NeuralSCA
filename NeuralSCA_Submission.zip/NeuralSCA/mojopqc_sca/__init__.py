"""MojoPQC-SCA research pipeline."""

__version__ = "0.1.0"
