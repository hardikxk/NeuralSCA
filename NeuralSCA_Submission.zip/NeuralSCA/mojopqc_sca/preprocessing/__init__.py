"""Streaming trace preprocessing."""
